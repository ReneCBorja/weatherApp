//
//  vmMainViewController.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import Alamofire
import ObjectMapper
import CoreLocation
import UIKit

class vmMainViewController: NSObject {
    var place = ""
    let act = Action()
    var data = WeatherResponse()
    let rest=Rest()
    var resultsTableViewController: MainViewController?

    func getWheater(place: String){
                rest.getClima(place:place ){ response,error in
                    if response != nil{
                        if let responseMain = response{
                            SharedManager.sharedInstance.data = responseMain
                            let urlImage = self.act.getUrlImgWeather(imgName: responseMain.weather?.first?.icon ?? "")
                            self.rest.getWeatherImage(urlImage: urlImage)
                        }
                    }else{
                      //  self.inErrorCase()
                    }
                }
    }
    func getWheaterLatLong(Lat: String, long: String, view: UIViewController){
        
                rest.getClimaLatLong(Lat: Lat, long: long){ response,error in
                    if response != nil{
                        if let responseMain = response{

                            SharedManager.sharedInstance.data = responseMain
                            let urlImage = self.act.getUrlImgWeather(imgName: responseMain.weather?.first?.icon ?? "")
                            self.rest.getWeatherImage(urlImage: urlImage)
                        }
                    }else{
                        self.inErrorCase(view: view)
                    }
                }
    }
    
    func inErrorCase(view: UIViewController){
        self.confirmDialog(tittle: "WeatherApp", msg: "Algo sucedio, deseas cargar datos locales?", textOk: "Sonsonate", textOk2: "San Miguel", textOk3: "Ahuachapan", textOk4: "San Salvador", textOk5: "Chalatenango", view: view)
    }
    
    func getCoordinates(for city: String, completion: @escaping (CLLocationCoordinate2D?) -> Void) {
        let geocoder = CLGeocoder()
        geocoder.geocodeAddressString(city) { (placemarks, error) in
            if let error = error {
                print("Error: \(error)")
                completion(nil)
            }
            if let placemarks = placemarks, let location = placemarks.first?.location {
                completion(location.coordinate)
            } else {
                completion(nil)
            }
        }
    }
    
    func confirmDialog(tittle:String,msg:String, textOk:String, textOk2:String, textOk3:String, textOk4:String, textOk5:String, view: UIViewController){
        let alert = UIAlertController(title: tittle, message: msg, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: textOk, style: .default, handler: { action in
            switch action.style{
            case .default:
                print("default")
                self.rest.getDataFromFile(mockName: "Sonsonate")
            case .cancel:
                print("cancel")
            case .destructive:
                print("destructive")
            @unknown default:
                print("error")
            }}))
        alert.addAction(UIAlertAction(title: textOk2, style: .default, handler: { action in
            switch action.style{
            case .default:
                print("default")
                self.rest.getDataFromFile(mockName: "SanMiguel")
            case .cancel:
                print("cancel")
            case .destructive:
                print("destructive")
            @unknown default:
                print("error")
            }}))
        alert.addAction(UIAlertAction(title: textOk3, style: .default, handler: { action in
            switch action.style{
            case .default:
                print("default")
                self.rest.getDataFromFile(mockName: "Ahuachapan")
            case .cancel:
                print("cancel")
            case .destructive:
                print("destructive")
            @unknown default:
                print("error")
            }}))
        alert.addAction(UIAlertAction(title: textOk4, style: .default, handler: { action in
            switch action.style{
            case .default:
                print("default")
                self.rest.getDataFromFile(mockName: "SanSalvador")
            case .cancel:
                print("cancel")
            case .destructive:
                print("destructive")
            @unknown default:
                print("error")
            }}))
        alert.addAction(UIAlertAction(title: textOk5, style: .default, handler: { action in
            switch action.style{
            case .default:
                print("default")
                self.rest.getDataFromFile(mockName: "Chalatenango")
            case .cancel:
                print("cancel")
            case .destructive:
                print("destructive")
            @unknown default:
                print("error")
            }}))
        alert.addAction(UIAlertAction(title: "Cancelar", style: .cancel, handler: { action in
            switch action.style{
            case .default:
                print("default")
            case .cancel:
                print("cancel")
                //Restuaramos el tipo de cancel.
            case .destructive:
                print("destructive")
            @unknown default:
                print("error")
            }}))

        self.act.topMostViewController().present(alert, animated: true, completion: nil)
    }
    
}
