//
//  vmMainViewController.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import Alamofire
import ObjectMapper


class vmMainViewController: NSObject {
    var place = ""
    let act = Action()
    var data = WeatherResponse()
    func getWheater(place: String){
            let rest=Rest()
                rest.getClima(place:place ){ response,error in
                    if response != nil{
                        if let responseMain = response{
                            SharedManager.sharedInstance.data = responseMain
                            let urlImage = self.act.getUrlImgWeather(imgName: responseMain.weather?.first?.icon ?? "")
                            rest.getWeatherImage(urlImage: urlImage)
                        }
                    }else{
                       
                    }
                }
            
        
    }
    
}
