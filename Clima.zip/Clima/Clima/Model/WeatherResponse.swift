//
//  WeatherResponse.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import ObjectMapper

public class WeatherResponse: NSObject, Mappable{
    var coord: Corrd?
    var weather: [Weather]?
    var base: String?
    var main: Main?
    var visibility: Int?
    var wind: Wind?
    var clouds: Clouds?
    var dt: Int?
    var sys: Sys?
    var timezone: Int?
    var id: Int?
    var name: String?
    var cod: Int?

    override init() {
        super.init()
    }

    
    required convenience public init?(map: Map) {
        self.init()
    }
    
    public func mapping(map: Map) {
        coord      <- map["coord"]
        weather      <- map["weather"]
        base      <- map["base"]
        main      <- map["main"]
        visibility      <- map["visibility"]
        wind      <- map["wind"]
        clouds      <- map["clouds"]
        dt      <- map["dt"]
        sys      <- map["sys"]
        timezone      <- map["timezone"]
        id      <- map["id"]
        name      <- map["name"]
        cod      <- map["cod"]


    }
}
