//
//  Weather.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import ObjectMapper

public class Weather: NSObject, Mappable{
    var id: Int?
    var main: String?
    var descrip: String?
    var icon: String?
 
    override init() {
        super.init()
    }

    
    required convenience public init?(map: Map) {
        self.init()
    }
    
    public func mapping(map: Map) {
        id      <- map["id"]
        main      <- map["main"]
        descrip      <- map["description"]
        icon      <- map["icon"]
    }
}
