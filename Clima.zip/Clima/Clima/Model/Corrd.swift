//
//  Corrd.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import ObjectMapper

public class Corrd: NSObject, Mappable{
    var lon: Double?
    var lat: Double?
    
    override init() {
        super.init()
    }

    
    required convenience public init?(map: Map) {
        self.init()
    }
    
    public func mapping(map: Map) {
        lon      <- map["lon"]
        lat      <- map["lat"]
    }
}


public class Clouds: NSObject, Mappable{
    var all: Int?
    
    override init() {
        super.init()
    }

    
    required convenience public init?(map: Map) {
        self.init()
    }
    
    public func mapping(map: Map) {
        all      <- map["all"]
    }
}
