//
//  Rest.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import Alamofire
import ObjectMapper
import UIKit

public class Rest{
    
    let act = Action()
    
    func getClima(place: String, completionHandler: @escaping (WeatherResponse?, Error?) -> ()) {
        getClimaRun(place: place, completionHandler: completionHandler)
        
    }
    
    private func getClimaRun(place: String, completionHandler: @escaping (WeatherResponse?, Error?) -> ()){
        let url = act.getUrlForPlace(lugar: place)
        print(url)
        AF.request(url, method: .get, encoding: JSONEncoding.default).validate().responseJSON{
            response in
            switch response.result {
            case .success(let value):
                debugPrint(value)
                completionHandler(Mapper<WeatherResponse>().map(JSONObject:value), nil)
            case .failure(let error):
                completionHandler(nil, error)
            }
        }
    }
    
    func getClimaLatLong(Lat: String, long: String, completionHandler: @escaping (WeatherResponse?, Error?) -> ()) {
        getClimaLatLongRun(Lat: Lat, long: long, completionHandler: completionHandler)
        
    }
    
    private func getClimaLatLongRun(Lat: String, long: String, completionHandler: @escaping (WeatherResponse?, Error?) -> ()){
        let url = act.getUrlLatLong(lat: Lat, Long: long)
        print(url)
        AF.request(url, method: .get, encoding: JSONEncoding.default).validate().responseJSON{
            response in
            switch response.result {
            case .success(let value):
                debugPrint(value)
                completionHandler(Mapper<WeatherResponse>().map(JSONObject:value), nil)
            case .failure(let error):
                completionHandler(nil, error)
            }
        }
    }
    
    func getWeatherImage(urlImage:String) {

        if let url = URL(string: urlImage) {
            print("Download Started")
            getData(from: url) { data, response, error in
                guard let data = data, error == nil else { return }
                SharedManager.sharedInstance.imageIcon = UIImage(data: data)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UpdateTemp"), object: nil)
                
            }
        }
        }
    
    func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    }
    
    
    
//    
//    func loadJson(filename fileName: String) -> WeatherResponse? {
//        if let url = Bundle.main.url(forResource: fileName, withExtension: "json") {
//            do {
//                let data = try Data(contentsOf: url)
//                let decoder = JSONDecoder()
//                let jsonData = try decoder.decode(WeatherResponse.self, from: data)
//                
//                return jsonData.person
//            } catch {
//                print("error:\(error)")
//            }
//        }
//        return nil
//    }
//    
    
    
    func getDataFromFile(mockName: String){
       
        if  let jsonData = MockUtils.readLocalFile(forName: mockName) {
            do {
                  let jsonResult = try JSONSerialization.jsonObject(with: jsonData, options: .mutableLeaves)
                if let data = Mapper<WeatherResponse>().map(JSONObject: jsonResult){
                    let rest = Rest()
                    SharedManager.sharedInstance.data = data
                    let urlImage = self.act.getUrlImgWeather(imgName: data.weather?.first?.icon ?? "")
                    rest.getWeatherImage(urlImage: urlImage)
                       }
              } catch {
                   // handle error
              }
        }
    }
    
}
