//
//  Rest.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import Alamofire
import ObjectMapper
import UIKit

public class Rest{
    
    let act = Action()
    
    func getClima(place: String, completionHandler: @escaping (WeatherResponse?, Error?) -> ()) {
        getClimaRun(place: place, completionHandler: completionHandler)
        
    }
    
    private func getClimaRun(place: String, completionHandler: @escaping (WeatherResponse?, Error?) -> ()){
        let url = act.getUrlForPlace(lugar: place)
        print(url)
        AF.request(url, method: .get, encoding: JSONEncoding.default).validate().responseJSON{
            response in
            switch response.result {
            case .success(let value):
                debugPrint(value)
                completionHandler(Mapper<WeatherResponse>().map(JSONObject:value), nil)
            case .failure(let error):
                completionHandler(nil, error)
            }
        }
    }
    
    func getWeatherImage(urlImage:String) {

        if let url = URL(string: urlImage) {
            print("Download Started")
            getData(from: url) { data, response, error in
                guard let data = data, error == nil else { return }
                SharedManager.sharedInstance.imageIcon = UIImage(data: data)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "UpdateTemp"), object: nil)
                
            }
        }
        }
    
    func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    }
    
}
