//
//  Wind.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import ObjectMapper

public class Wind: NSObject, Mappable{
    var speed: Double?
    var deg: Double?
    var gust: Double?
  

    override init() {
        super.init()
    }

    
    required convenience public init?(map: Map) {
        self.init()
    }
    
    public func mapping(map: Map) {
        speed      <- map["speed"]
        deg      <- map["deg"]
        gust      <- map["gust"]

    }
}

