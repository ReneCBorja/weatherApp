//
//  Constants.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import UIKit


public class Action{
  //  let apiKey = "d059036fd7d00cf47cccae737e63604e"
    var imgWeather = UIImage(named: "circle.dotted")
    let apiKey = "fc84c9149b7ccc453aed9bf1f979dc0c"
    
    
    
    func getUrlLatLong(lat: String, Long: String) -> String{
        
        return "https://api.openweathermap.org/data/2.5/weather?503&lat=\(lat)&lon=\(Long)&&lang=es&appid=\(apiKey)"
    }
    func getUrlImgWeather(imgName: String) -> String{
        
        return "http://openweathermap.org/img/wn/\(imgName)@2x.png"
    }
    
    func getUrlForPlace(lugar: String) -> String{
        
        return "https://api.openweathermap.org/data/2.5/weather?q=\(lugar)&lang=es&appid=\(apiKey)"
    }
    
    
    func convertTemp(temp: Double, from inputTempType: UnitTemperature, to outputTempType: UnitTemperature) -> String {
        let mf = MeasurementFormatter()
        mf.numberFormatter.maximumFractionDigits = 0
        mf.unitOptions = .providedUnit
        let input = Measurement(value: temp, unit: inputTempType)
        let output = input.converted(to: outputTempType)
        return mf.string(from: output)
    }
    
    func topMostViewController() -> UIViewController {
    var topViewController: UIViewController? = UIApplication.shared.keyWindow?.rootViewController
    while ((topViewController?.presentedViewController) != nil) {
    topViewController = topViewController?.presentedViewController
    }
    return topViewController!
    }
    
    
    
    
}

class SharedManager {
    static var sharedInstance = SharedManager()
    private init() {}
    
    var imageIcon: UIImage?
    var data = WeatherResponse()

}

struct MockUtils{
    static func loadMockModelJson<T>(_ json:String,type: T.Type) -> T where T : Decodable{
        return try! JSONDecoder().decode(T.self, from: json.data(using: .utf8)!)
    }
    
    static func readLocalFile(forName name: String) -> Data? {
        do {
            if let bundlePath = Bundle.main.path(forResource: name,
                                                 ofType: "json"),
                let jsonData = try String(contentsOfFile: bundlePath).data(using: .utf8) {
                return jsonData
            }
        } catch {
            print(error)
        }
        
        return nil
    }
}



