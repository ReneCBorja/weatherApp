//
//  Constants.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import UIKit


public class Action{
    let apiKey = "d059036fd7d00cf47cccae737e63604e"
    var imgWeather = UIImage(named: "circle.dotted")

    func getUrlLatLong(lat: String, Long: String) -> String{
        
        return "https://api.openweathermap.org/data/2.5/weather?503&lat=\(lat)&lon=\(Long)&&lang=es&appid=\(apiKey)"
    }
    func getUrlImgWeather(imgName: String) -> String{
        
        return "http://openweathermap.org/img/wn/\(imgName)@2x.png"
    }
    
    func getUrlForPlace(lugar: String) -> String{
        
        return "https://api.openweathermap.org/data/2.5/weather?q=\(lugar)&lang=es&appid=\(apiKey)"
    }
    
    
    func convertTemp(temp: Double, from inputTempType: UnitTemperature, to outputTempType: UnitTemperature) -> String {
        let mf = MeasurementFormatter()
        mf.numberFormatter.maximumFractionDigits = 0
        mf.unitOptions = .providedUnit
        let input = Measurement(value: temp, unit: inputTempType)
        let output = input.converted(to: outputTempType)
        return mf.string(from: output)
    }
    
    
    
}

class SharedManager {
    static var sharedInstance = SharedManager()
    private init() {}
    
    var imageIcon: UIImage?
    var data = WeatherResponse()

}
