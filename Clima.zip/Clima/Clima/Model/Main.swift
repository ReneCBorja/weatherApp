//
//  Main.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import ObjectMapper

public class Main: NSObject, Mappable{
    var temp: Double?
    var feels_like: Double?
    var temp_min: Double?
    var temp_max: Double?
    var pressure: Double?
    var humidity: Double?


    override init() {
        super.init()
    }

    
    required convenience public init?(map: Map) {
        self.init()
    }
    
    public func mapping(map: Map) {
        temp      <- map["temp"]
        feels_like      <- map["feels_like"]
        temp_min      <- map["temp_min"]
        temp_max      <- map["temp_max"]
        pressure      <- map["pressure"]
        humidity      <- map["humidity"]
      
    }
}

