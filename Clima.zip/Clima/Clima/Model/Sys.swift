//
//  Sys.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import Foundation
import ObjectMapper

public class Sys: NSObject, Mappable{
    var type: Int?
    var id: Int?
    var country: String?
    var sunrise: Int?
    var sunset: Int?
    
    override init() {
        super.init()
    }

    
    required convenience public init?(map: Map) {
        self.init()
    }
    
    public func mapping(map: Map) {
        type      <- map["type"]
        id      <- map["id"]
        country      <- map["country"]
        sunrise      <- map["sunrise"]
        sunset      <- map["sunset"]
    }
}

