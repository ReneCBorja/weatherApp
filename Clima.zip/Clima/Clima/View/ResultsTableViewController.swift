//
//  ResultsTableViewController.swift
//  Clima
//
//  Created by Rene Borja on 26/1/23.
//

import Foundation
import UIKit

class ResultsTableViewController: UITableViewController, UISearchResultsUpdating, UISearchBarDelegate {
    var act = Action()
    var array = ["San Salvador", "Ahuachapán", "Cabañas", "Chalatenango", "Cuscatlán", "La Libertad", "La Paz", "La Unión", "Morazán", "San Miguel", "San Vicente", "Santa Ana", "Sonsonate", "Usulután"]

    var arrayFilter = [String]()

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrayFilter.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "searchCell", for: indexPath)

        cell.textLabel?.text = arrayFilter[indexPath.row]

        return cell
    }


    func updateSearchResults(for searchController: UISearchController) {


    }

    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {

        arrayFilter.removeAll()

        if let text = searchBar.text {
            for string in array {
                if string.contains(text) {
                    arrayFilter.append(string)
                    tableView.reloadData()
                }
            }
        }

        tableView.reloadData()
        let vm = vmMainViewController()
        vm.getCoordinates(for: searchBar.text ?? "") { (coordinate) in
            print(coordinate?.latitude ?? 0.0)
            print(coordinate?.longitude ?? 0.0)
            vm.getWheaterLatLong(Lat: "\(coordinate?.latitude ?? 0.0)", long: "\(coordinate?.longitude ?? 0.0)", view: self)

        }
        self.dismiss(animated: true, completion: nil)

    }

    func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {

        arrayFilter.removeAll()
        tableView.reloadData()
    }

    func searchBarShouldBeginEditing(_ searchBar: UISearchBar) -> Bool {

        arrayFilter.removeAll()
        tableView.reloadData()

        return true
    }
}
