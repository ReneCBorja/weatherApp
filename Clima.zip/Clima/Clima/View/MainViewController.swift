//
//  MainViewController.swift
//  Clima
//
//  Created by Rene Borja on 25/1/23.
//

import UIKit
import Foundation

class MainViewController: UIViewController {

    @IBOutlet weak var btnChangeTemp: UIButton!
    @IBOutlet weak var searchCity: UISearchBar!
    @IBOutlet weak var lblCity: UILabel!
    @IBOutlet weak var lblTemp: UILabel!
    
    @IBOutlet weak var imgWeather: UIImageView!
    @IBOutlet weak var lblDescription: UILabel!
    @IBOutlet weak var searchResultsTable: UITableView!
    let vm = vmMainViewController()
    let act = Action()
    var cambiarMedida = false
    var controladorDeBusca: UISearchController!
    var resultsTableViewController: ResultsTableViewController?
    override func viewDidLoad() {
        super.viewDidLoad()
       initConfig()
      vm.getWheater(place: "El Salvador")
     
   //     print("Print:::", act.convertTemp(temp: 300.86, from: .kelvin, to: .celsius))

    }
    
    func initConfig()  {
        let name = Notification.Name(rawValue: "UpdateTemp")
        NotificationCenter.default.addObserver(
            self, selector: #selector(updateUI),
            name: name, object: nil)
        resultsTableViewController = storyboard!.instantiateViewController(withIdentifier: "resultsTableViewController") as? ResultsTableViewController
        configurarControladorDeBusca()
    }
    
    func setUpUI(){
        lblDescription.adjustsFontSizeToFitWidth = true
    }
    
    @IBAction func btnBuscarAction(_ sender: Any) {
        if self.cambiarMedida == true {
            self.lblTemp.text = self.act.convertTemp(temp: SharedManager.sharedInstance.data.main?.temp ?? 0.0, from: .kelvin, to: .celsius)
            self.cambiarMedida = false
        }else{
            self.lblTemp.text = self.act.convertTemp(temp: SharedManager.sharedInstance.data.main?.temp ?? 0.0, from: .kelvin, to: .fahrenheit)
            self.cambiarMedida = true
        }
        
    }
    
    
    @objc func updateUI() {
        DispatchQueue.main.async() { [weak self] in
            
            
            self?.lblTemp.text = self?.act.convertTemp(temp: SharedManager.sharedInstance.data.main?.temp ?? 0.0, from: .kelvin, to: .celsius)
            self?.lblCity.text = SharedManager.sharedInstance.data.name ?? ""
            self?.lblDescription.text = SharedManager.sharedInstance.data.weather?.first?.descrip ?? ""
            self?.imgWeather.image =  SharedManager.sharedInstance.imageIcon
        }
        
    }


}



extension MainViewController: UISearchControllerDelegate {

  
 

    func configurarControladorDeBusca() {

        controladorDeBusca = UISearchController(searchResultsController: resultsTableViewController)
        controladorDeBusca.delegate = self
        controladorDeBusca.searchResultsUpdater = resultsTableViewController
        controladorDeBusca.dimsBackgroundDuringPresentation = true
        definesPresentationContext = true

        controladorDeBusca.loadViewIfNeeded()

        //Configura a barra do Controlador de busca
        controladorDeBusca.searchBar.delegate = resultsTableViewController
        controladorDeBusca.hidesNavigationBarDuringPresentation = false
        controladorDeBusca.searchBar.placeholder = "Buscar..."
        controladorDeBusca.searchBar.sizeToFit()
        controladorDeBusca.searchBar.barTintColor = navigationController?.navigationBar.barTintColor
        controladorDeBusca.searchBar.tintColor = self.view.tintColor

        //Adiciona a barra do Controlador de Busca a barra do navegador
        navigationItem.titleView = controladorDeBusca.searchBar
    }
}
